# Projeto de IAED
## Sparse Matrices

### Version 1.0
- Code has been initiated.
- Already have a menu
- Main function written
- Using own library that contains small functions
- Code in its first stages

### Version 1.1
- Main function architecture implemented
- Element represented by structure
- Created global variable that contains the matrix
- Implemented functions for assigning new elements to matrix
and printing the matrix

### Version 1.2
- Sort matrix and compress matrix to be constructed
- All other functions are operational
- Program acts as expected
- Still need to implement reading a matrix from the console
- Warnings: comparing unsigned with normal int
